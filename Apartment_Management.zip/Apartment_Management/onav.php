<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
?>

<nav class="navbar navbar-default navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
        <a class="navbar-brand" href="odashboard.php">Apartment Management</a>
    </div>
    <ul class="nav navbar-nav pull-right">
        <li><a href="tenantReg.php">RegisterTenant</a></li>
        <li><a href="viewtenants.php">MyTenant</a></li>
      <li><a href="logout.php">Logout</a></li>
    </ul>
  </div>
</nav>
