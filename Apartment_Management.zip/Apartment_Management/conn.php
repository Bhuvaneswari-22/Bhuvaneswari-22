<?php

$con = mysqli_connect('localhost','root','','apartment');

if(!$con){
die('Database Connection Lost');
    
}// database name  --> 'ibdf' 

//if($con){
  //  echo "Connected";
//}else{
  //  echo "Not Connected";
//}

?>